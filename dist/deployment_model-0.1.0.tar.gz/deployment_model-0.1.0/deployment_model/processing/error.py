class BaseError(Exception):


class InvalidModelInputError(BaseError):